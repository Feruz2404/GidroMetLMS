# Task 2-b — Quizzes/Test Module (full-stack-developer)

## Summary
Built the complete Quizzes/Test module — backend API + frontend views — handling 4 question types, timed test-taking, automatic scoring, results review, and certificate-eligibility logging.

## Work Log
1. Read worklog.md to learn foundation + courses-module conventions (db, auth helpers, api client, nav store, teal theme, Uzbek UI).
2. Inspected prisma/schema.prisma (Quiz, Question, AnswerOption, QuizAttempt, QuizAnswer models), src/lib/auth.ts (ok/err/logActivity helpers), src/lib/api.ts (Quiz/Question types), src/store/auth.ts (useAuth/useNav), src/components/views/courses-view.tsx (filtering/pagination/loading patterns).
3. Created `src/app/api/quizzes/route.ts`:
   - GET: paginated (page/limit), filterable (search, courseId, status). Role-aware: students only see published; tutors/admins see published + their own.
   - For students: returns `myAttempts` (count incl. in_progress) + `bestScore` (max percentage among graded).
   - POST (tutor/admin): creates quiz with nested questions + options in single transaction; validates per-question (type, text, options, at least one correct).
4. Created `src/app/api/quizzes/[id]/route.ts`:
   - GET: returns quiz with questions/options. **CRITICAL**: strips `isCorrect` from options + nulls `explanation` for students (security: don't reveal answers pre-submission).
   - Returns user's previous attempts + `maxAttemptsExceeded` flag (in_progress + graded both count toward limit).
   - PATCH: tutor/admin update quiz metadata.
5. Created `src/app/api/quizzes/[id]/attempt/route.ts`:
   - POST: creates QuizAttempt with status="in_progress".
   - Validates quiz is published, questions exist, maxAttempts not exceeded.
   - Auto-fails any previous in_progress attempt (zero score) when creating a new one.
   - Returns questions with options (isCorrect stripped) + timeLimitMin + startedAt + attemptsRemaining.
   - Honors shuffleQuestions by randomizing question order.
6. Created `src/app/api/quizzes/attempts/[id]/route.ts`:
   - GET: returns attempt with full answers + correct options (gated by `quiz.showAnswers` OR staff role).
   - POST (submit): grades each answer:
     - single_choice / true_false: correct if selected option isCorrect
     - multiple_choice: full points if all correct + none incorrect; partial credit (points × correct/total) if subset of correct selected with no incorrect; 0 if any incorrect selected
     - fill_blank: case-insensitive trimmed text match against any correct option
   - Computes score/maxScore/percentage/passed, sets status="graded", submittedAt, timeSpentSec.
   - Creates QuizAnswer records for each question.
   - On first pass with linked course + active enrollment: logs `certificate_eligible` activity (Certificates module agent will pick up).
7. Built `src/components/views/quizzes-view.tsx`:
   - Header with title + "Yangi test yaratish" button (staff).
   - Filter bar: debounced search, course Select, status Select (staff only).
   - Grid (1/2/3 cols) of quiz cards: title, description, course badge, status badge, question/time/passing-score meta, attempts progress bar (X / maxAttempts), best-score badge.
   - Student actions: "Testni boshlash" / "Qayta urinish" + "Natija" (if has graded attempts). Disabled when maxAttempts reached.
   - Staff actions: "Ko'rish" button (preview).
   - Loading skeletons, empty state with clear-filters CTA, pagination.
8. Built `src/components/views/quiz-taking-view.tsx`:
   - Two modes via params: taking (default) or review (mode=review).
   - **Taking mode**:
     - On mount: POST to create attempt → get questions (deferred via microtask to satisfy react-hooks/set-state-in-effect rule).
     - Sticky top bar: quiz title, answered-count, countdown timer (mm:ss, turns red + pulse when ≤60s), Topshirish button.
     - Anti-cheat banner (visual only).
     - Question navigator sidebar (sticky on desktop): numbered grid buttons colored by answered/unanswered, click to jump.
     - Main card: question text + type badge + points badge, input rendered by type (RadioGroup for single/tf, Checkboxes for multi, Input for fill_blank).
     - Prev/Next + "Belgilangan javoblar" counter.
     - Submit confirmation Dialog showing answered/unanswered counts.
     - Auto-submit when timer hits 0 (deferred via microtask).
   - **Results mode**:
     - Big score display: percentage, score/maxScore, PASSED/FAILED trophy badge, passing-score progress bar with marker.
     - Stats grid: correct/wrong/total/time-spent.
     - Per-question review (if showAnswers): green check / red X icons, color-coded options (user-correct / correct / user-wrong), explanation card.
     - If showAnswers=false: shows score only with "Javoblar yashirilgan" notice.
     - "Qayta urinish" button (if attempts remaining) + "Testlar ro'yxatiga" back button.
   - Mobile-responsive throughout (grid collapses, navigator stays usable).
9. Fixed ESLint issues:
   - Removed unused eslint-disable directives (2 warnings → resolved).
   - Moved `submitAnswers` useCallback before the auto-submit useEffect that uses it (fixed "Cannot access variable before it is declared").
   - Inlined `isQuestionAnswered` inside `answeredCount` useMemo (fixed react-hooks/preserve-manual-memoization).
   - Deferred setState calls inside effects via `Promise.resolve().then(...)` (fixed react-hooks/set-state-in-effect).
10. Fixed maxAttempts bug: in_progress attempts now count toward limit (previously student could start unlimited attempts by triggering force-fail of previous in_progress).
11. End-to-end smoke-tested all 4 API routes via curl as student + tutor:
    - GET /api/quizzes (student): 2 published quizzes, correct myAttempts/bestScore.
    - GET /api/quizzes/[id] (student): isCorrect stripped, explanation nulled, maxAttemptsExceeded flag correct.
    - POST /api/quizzes/[id]/attempt (student): creates attempt, returns shuffled questions with isCorrect stripped, attemptsRemaining correct.
    - POST /api/quizzes/attempts/[id] (submit): partial credit verified (1/2 correct on multi → 1.5/3), fill_blank case-insensitive + trim verified ("  EVAPORATSIYA  " matched), correctOptions revealed only when showAnswers=true.
    - GET /api/quizzes/attempts/[id] (review): returns full answer details with correct options gated by showAnswers.
    - POST /api/quizzes (tutor): creates quiz with questions + options.
    - maxAttempts enforcement: blocked 3rd attempt with "Urinishlar soni tugadi" (403).
12. Cleaned up all test data (5 attempts + 8 answers + 8 activity logs) via direct Prisma script — database returned to clean seeded state.

## Stage Summary
- Files created:
  - src/app/api/quizzes/route.ts (GET list + POST create)
  - src/app/api/quizzes/[id]/route.ts (GET detail + PATCH update)
  - src/app/api/quizzes/[id]/attempt/route.ts (POST start attempt)
  - src/app/api/quizzes/attempts/[id]/route.ts (GET review + POST submit/grade)
- Files modified:
  - src/components/views/quizzes-view.tsx (replaced stub with full implementation)
  - src/components/views/quiz-taking-view.tsx (replaced stub with full implementation)
- Key decisions:
  - **Answer security**: isCorrect is stripped from AnswerOption responses for students at every API surface (list, detail, attempt-start, review-when-showAnswers-off). Only tutors/admins or post-submission with quiz.showAnswers=true can see correct flags.
  - **maxAttempts semantics**: in_progress + graded + submitted all count toward the limit. Starting a new attempt auto-fails any existing in_progress (with 0 score), preventing "stuck" attempts from blocking students.
  - **Multiple-choice partial credit**: 0 if any wrong option selected; full if all correct + no wrong; proportional (points × correct/total) for partial subset without wrong — matches TZ "to'g'ri javoblar tanlanganda to'liq ball, qisman to'g'ri bo'lsa proporsional" intent.
  - **Certificate eligibility**: not auto-issued (out of scope); instead logged as `certificate_eligible` activity on first pass with linked course + enrollment — Certificates module agent can query this activity log to issue the actual cert.
  - **Timer**: client-side countdown from `startedAt + timeLimitMin*60`; auto-submits on 0. Server records `timeSpentSec` based on actual server timestamps for integrity.
  - **Anti-cheat**: visual warning banner only (no actual tab-switch detection per spec).
  - **Lint compliance**: deferred setState in effects via microtask pattern (matches courses-view.tsx convention); submitAnswers useCallback declared before effects that use it.
- Verification results:
  - `bun run lint` — passes with 0 errors, 0 warnings.
  - Dev server returns HTTP 200 on `/` and all `/api/quizzes*` endpoints (200/403 as appropriate).
  - All 4 endpoints tested end-to-end with curl (student + tutor roles) — grading math, security stripping, maxAttempts enforcement, partial credit, fill_blank case-insensitivity all verified.
  - Database cleaned of test data (back to seeded state: Nodira has 1 attempt on quiz 1 at 70%, 0 attempts on quiz 2).
