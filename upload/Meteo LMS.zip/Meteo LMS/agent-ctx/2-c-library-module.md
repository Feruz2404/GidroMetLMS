# Task 2-c — Library Module (full-stack-developer)

## Summary
Built the complete Library module — backend API + frontend views — for managing digital resources (books, articles, videos, audio, documents, normative documents) with search, filtering, bookmarking, viewing, and download tracking.

## Work Log
1. Read worklog.md to align with foundation + courses + quizzes conventions (db, auth helpers, api client, nav store, teal theme, Uzbek UI, deferred-setState-in-effect pattern).
2. Inspected prisma/schema.prisma (LibraryResource, ResourceDownload, ResourceBookmark models with @@unique([resourceId, userId]) on bookmark), src/lib/auth.ts (ok/err/logActivity helpers), src/lib/api.ts (LibraryResource type + formatFileSize/formatDate helpers), src/store/auth.ts (useAuth/useNav), src/components/views/courses-view.tsx (filter/pagination/loading patterns), prisma/seed.ts (12 seeded resources, 3 bookmarks for first student).
3. Created `src/app/api/library/route.ts`:
   - GET: paginated (page/limit default 12, capped at 60). Filterable: search (title/author/description/tags via OR), type, category, year, language, bookmarks=true (limit to current user's bookmarks via `bookmarks: { some: { userId } }`). Sortable: newest (createdAt desc), popular (viewCount desc), downloads (downloadCount desc), title (asc). Only `status=active` resources returned. Includes flattened `bookmarked: boolean` flag per resource for current user.
   - POST (tutor/admin): creates LibraryResource record; validates title length >= 3; validates type against enum; defaults fileUrl to '#', language to 'uz', status to 'active'; logs `create_resource` activity.
4. Created `src/app/api/library/[id]/route.ts`:
   - GET: returns full resource details including uploader info; increments viewCount via Prisma `{ increment: 1 }`; returns updated viewCount (DB value + 1) to client; includes `bookmarked` flag.
   - Visibility: archived resources only visible to tutor/admin (students get 404).
   - PATCH (tutor/admin): updates whitelisted fields (title, description, type, category, author, publisher, year, language, pages, fileUrl, fileSize, fileType, coverUrl, tags, status). Tutors can only edit their own uploads; admins can edit any.
   - DELETE (tutor/admin): soft-archives resource (sets status='archived'); same ownership check; logs `archive_resource` activity.
5. Created `src/app/api/library/[id]/bookmark/route.ts`:
   - GET: returns `{ bookmarked, bookmarkId }` for current user.
   - POST: toggles bookmark — if exists, delete (return `{ bookmarked: false, action: 'removed' }`); if not, create (return `{ bookmarked: true, action: 'added' }`). Uses Prisma's compound unique `resourceId_userId` lookup so it's race-safe for the same user.
6. Created `src/app/api/library/[id]/download/route.ts`:
   - POST: creates ResourceDownload record, increments downloadCount, logs `download_resource` activity with metadata (title, fileType). Returns `{ fileUrl, fileType, fileSize, downloadCount }` (in a real app fileUrl would be a signed URL — for demo we return the stored value which is '#').
   - Archived resources not downloadable for students.
7. Built `src/components/views/library-view.tsx`:
   - Header with title + "Mening xatcho'plarim" toggle button (filters to bookmarks=true) + "Yangi resurs" button (staff only, toast placeholder).
   - Filter bar: debounced search (350ms, searches title/author/description/tags), type Select (book/article/video/audio/document/normative), category Select (auto-populated from results on first unfiltered load), year Select (auto-populated), sort Select (newest/popular/downloads/title), clear-filters button.
   - Responsive grid (1/2/3/4 cols) of resource cards: cover image OR type-icon gradient placeholder, type badge (color-coded per type), category badge, bookmark toggle button (star — optimistic update with revert on error), file format badge, title (line-clamp-2), description (line-clamp-2), author + year, file size (formatFileSize), view count, download count.
   - Click card → navigate('library-detail', { id }).
   - Loading skeletons (8 cards), empty state (different message for bookmarks-only vs filtered), pagination (prev/next + 5 numbered buttons).
   - Bookmark filter state persisted in component; button turns default-filled when active.
8. Built `src/components/views/library-detail-view.tsx`:
   - Reads `id` from `useNav(s => s.params).id`.
   - Two-column layout on desktop (lg:grid-cols-3): main (lg:col-span-2) + sidebar.
   - **Main column**:
     - Hero card: large cover image (or 20x20 type-icon placeholder on gradient), title overlay, type badge + category badge.
     - Title (2xl/3xl), author info.
     - Action buttons: "Yuklab olish" (download — calls POST /download, opens fileUrl in new tab if not '#'), "Xatcho'pga qo'shish"/"Xatcho'pdan olib tashlash" (bookmark toggle — optimistic update with revert on error).
     - Description card (whitespace-pre-line) + tags as badges (parsed from comma-separated tags string).
     - Metadata card: 2-col grid of MetaItem components (publisher, year, language, pages, file format, file size, uploader, created date) with icons.
   - **Sidebar**:
     - Inline viewer card: ResourceViewer component renders appropriate UI by type:
       - video: HTML5 <video> with controls (uses fileUrl; falls back to styled placeholder card with download CTA when fileUrl is '#').
       - audio: <audio> player + album-art-style placeholder (similar fallback).
       - book/article/document/normative: 3:4 aspect placeholder card with type icon + "Fayl ko'rish maydoni — yuklab olish uchun pastdagi tugmadan foydalaning" + download button showing file size.
     - Stats card: 2-col grid of StatBlock (viewCount, downloadCount) with icons.
     - Related resources card: fetches 5 from same category via GET /library?category=X&sort=popular, filters out current, takes 4. Renders as small clickable rows with type icon + title + author/year + arrow. Scrollable (max-h-96 overflow-y-auto).
   - Back button to library, loading skeletons, 404 empty state.
   - Mobile responsive (single column on small screens).
9. ESLint compliance: module-level `ResourceTypeIcon` component (avoids react-hooks/static-components error), deferred setState via `Promise.resolve().then(...)` in effects (matches courses-view.tsx convention), all imports used.
10. End-to-end smoke-tested all 4 API route files via curl as student + admin:
    - GET /api/library?limit=4 → 4 active resources with `bookmarked: false/true` flags.
    - GET /api/library?search=gidro → 6 resources matching title/author/description/tags.
    - GET /api/library?bookmarks=true → 3 seeded bookmarks for student.
    - GET /api/library/[id] → full detail with uploader, viewCount incremented (+1 returned), bookmarked flag correct.
    - GET /api/library/[id]/bookmark → { bookmarked: true, bookmarkId }.
    - POST /api/library/[id]/bookmark (toggle) → removed → re-added (idempotent).
    - POST /api/library/[id]/download → fileUrl returned, downloadCount incremented, ResourceDownload record + activity log created.
    - 404 on unknown resource, 403 on POST as student.
    - POST /api/library (admin) → creates resource with auto-defaults; PATCH → updates title + year; DELETE → archives; subsequent GET as student → 404 (visibility check works).
11. Cleaned up all test data (2 test resources, 1 test download, 1 test activity log, restored downloadCount/viewCount increments on 2 seeded resources) — database returned to clean seeded state (12 resources, 3 bookmarks, 0 downloads, 3 resource activity logs).

Stage Summary:
- Files created:
  - src/app/api/library/route.ts (GET list + POST create)
  - src/app/api/library/[id]/route.ts (GET detail with viewCount increment + PATCH update + DELETE archive)
  - src/app/api/library/[id]/bookmark/route.ts (GET status + POST toggle)
  - src/app/api/library/[id]/download/route.ts (POST record download + increment counter)
- Files modified:
  - src/components/views/library-view.tsx (replaced stub with full implementation)
  - src/components/views/library-detail-view.tsx (replaced stub with full implementation)
- Key decisions:
  - **Bookmark flag flattening**: each list/detail query includes `bookmarks: { where: { userId }, select: { id } }` so we can compute `bookmarked: bookmarks.length > 0` in a single round-trip (avoids N+1 calls to bookmark endpoint from the list view).
  - **Bookmarks filter**: implemented server-side via Prisma relation filter `bookmarks: { some: { userId } }` — efficient single query rather than fetching all then filtering client-side.
  - **viewCount increment on GET**: every detail fetch increments viewCount (fire-and-forget `db.update` with `{ increment: 1 }`); the API returns `viewCount + 1` so the client sees the post-increment value without a refetch.
  - **Soft delete (archive)**: DELETE sets `status='archived'` rather than hard-deleting (preserves download/bookmark history + referential integrity). Archived resources invisible to students via where clause + explicit visibility check.
  - **Ownership for tutors**: tutors can only PATCH/DELETE their own uploads (`uploadedBy !== user.id` → 403); admins can edit any.
  - **Optimistic bookmark toggle**: both list view (ResourceCard star button) and detail view (bookmark button) update UI immediately and revert on API error — keeps interaction snappy.
  - **Inline viewer fallback**: since seed data uses `fileUrl: '#'`, the viewer gracefully falls back to a styled placeholder card with a download CTA. If a real URL is provided, video/audio use HTML5 players; PDF/document types still show the placeholder (per spec — actual PDF rendering not required).
  - **Auto-populated filter dropdowns**: category and year Select options are extracted from the first unfiltered page of results (avoids a separate /api/library/categories endpoint; keeps options stable while user is filtering).
  - **Type colors**: teal (book), emerald (article), rose (video), purple (audio), amber (document), slate (normative) — distinct, accessible, on-theme with the teal primary palette.
- Verification results:
  - `bun run lint` — passes with 0 errors, 0 warnings.
  - Dev server returns HTTP 200 on `/` and all `/api/library*` endpoints (200/403/404 as appropriate).
  - All 4 route files (7 endpoints total: GET/POST /api/library, GET/PATCH/DELETE /api/library/[id], GET/POST /api/library/[id]/bookmark, POST /api/library/[id]/download) tested end-to-end with curl (student + admin roles) — search/filter/bookmark toggle/download tracking/archive visibility all verified.
  - Database cleaned of test data (back to seeded state: 12 resources, 3 bookmarks, 0 downloads, 3 resource activity logs from seed).
