# Task 10-a — i18n Migration: Dashboard + Courses views

## Summary
Migrated `dashboard-view.tsx`, `courses-view.tsx`, and `course-detail-view.tsx` to use the new i18n system (`useTranslation` hook from `@/lib/i18n`). All hardcoded Uzbek UI text has been replaced with `t('key')` calls. Missing keys were added to all 3 language dictionaries (uz/ru/en) in `src/lib/i18n.ts`.

## Files modified
- `src/lib/i18n.ts` — added 56 new translation keys to each of `uz`, `ru`, `en` dictionaries (168 entries total)
- `src/components/views/dashboard-view.tsx` — full i18n migration
- `src/components/views/courses-view.tsx` — full i18n migration; removed hardcoded `LEVEL_LABELS` map (now uses `t('courses.level.*')`)
- `src/components/views/course-detail-view.tsx` — full i18n migration; removed hardcoded `LEVEL_LABELS` map; converted `formatDuration` helper to accept a `t` function parameter; removed unused `ChevronRight` / `Loader2` imports

## Key changes per view

### dashboard-view.tsx
- Added `useTranslation` to `StudentDashboard`, `TutorDashboard`, `AdminDashboard`
- Recharts data now uses translated labels as `dataKey` (e.g. `t('dashboard.chart.lessons')`, `t('dashboard.chart.users')`, `t('dashboard.chart.students')`) — works because the chart re-maps data on every render
- Pie chart `pieData[].name` now uses translated strings (`t('dashboard.chart.students')`, etc.) so the Legend shows translated labels
- Date locale switches based on current language via `LOCALE_MAP` (`uz-UZ` / `ru-RU` / `en-US`)
- StatCard `label` prop still receives plain string — all callers now pass `t('...')`
- All "Barchasi" buttons → `t('common.viewAll')`
- All "Hozircha kurslaringiz yo'q" / "Sertifikatlar yo'q" / "Testlar topshirilmagan" → `t('courses.noCourses')` / `t('empty.noCertificates')` / `t('dashboard.noTestsTaken')`
- "ball" suffix → `t('quizzes.points')`

### courses-view.tsx
- Removed hardcoded `LEVEL_LABELS` constant — now uses `t(\`courses.level.${course.level}\`)` with fallback
- Kept `LEVEL_COLORS` (CSS classes only)
- All toast titles/descriptions translated
- Filter placeholders, "Tozalash", pagination "Oldingi"/"Keyingi" all translated
- Empty-state messages use `t('courses.tryChangeFilters')` and `t('courses.noneAvailable')`
- CourseCard receives `t` via its own `useTranslation` hook (instead of prop-drilling)
- Result count line: `${meta.total} ${t('courses.foundCount')}` (handles UZ "12 ta kurs topildi", RU "12 курсов найдено", EN "12 courses found")

### course-detail-view.tsx
- Removed hardcoded `LEVEL_LABELS` constant — uses `levelLabel(level, t)` helper that calls `t(\`courses.level.${level}\`)`
- `formatDuration(min)` → `formatDuration(min, t)` — uses `t('time.minutes_short')` and `t('common.hours')` for unit suffixes
- All toast messages translated: enroll success/error, mark-complete success/error, course-completed congrats
- All section headers, button labels, badges, empty states, PDF/Assignment/Video placeholders, "What you'll learn" bullets all translated
- Date locale switches based on current language for deadline display
- `LessonSidebar`, `LessonListItem`, `LessonViewer`, `CourseInfoPanel` each call `useTranslation()` independently (no prop drilling)
- The 4 "What you'll learn" bullets are now `t('courses.learnPoint1')` ... `t('courses.learnPoint4')`

## Keys added to all 3 dictionaries (uz/ru/en)
- `common.comingSoon`, `common.congrats`, `common.clear`
- `dashboard.currentCoursesDesc`, `dashboard.myCertificatesDesc`, `dashboard.recentTestsDesc`, `dashboard.testAttempts`, `dashboard.myCoursesDesc`, `dashboard.noTestsTaken`, `dashboard.activeUsers30`, `dashboard.chart.students`, `dashboard.chart.tutors`, `dashboard.chart.admins`, `dashboard.chart.users`, `dashboard.chart.lessons`
- `courses.heroSubtitle`, `courses.loadError`, `courses.enrollSuccess`, `courses.enrollError`, `courses.createFormSoon`, `courses.level`, `courses.foundCount`, `courses.startLearning`, `courses.tryChangeFilters`, `courses.noneAvailable`, `courses.clearFilters`, `courses.noCategory`, `courses.noDescription`, `courses.notFound`, `courses.yourProgress`, `courses.lessonsCompletedSuffix`, `courses.deadline`, `courses.lessonList`, `courses.selectLesson`, `courses.selectLessonDesc`, `courses.enrollToView`, `courses.lessons`, `courses.enrollPrompt`, `courses.noLessons`, `courses.lessonType.video`, `courses.lessonType.text`, `courses.lessonType.pdf`, `courses.lessonType.assignment`, `courses.enrollForVideo`, `courses.pdfDoc`, `courses.pdfDesc`, `courses.noFile`, `courses.assignment`, `courses.assignmentDesc`, `courses.noContent`, `courses.lessonAlreadyCompleted`, `courses.markCompletePrompt`, `courses.lessonCompleted`, `courses.courseProgressIs`, `courses.about`, `courses.startToday`, `courses.enrollTodayDesc`, `courses.learnPoint1`, `courses.learnPoint2`, `courses.learnPoint3`, `courses.learnPoint4`, `courses.levelLabel`, `courses.completedCongrats`, `courses.completedDesc`, `courses.progressSaveError`

## Verification
- `bun run lint` — passes with exit code 0 (zero errors)
- No remaining hardcoded Uzbek UI text in any of the 3 target views (verified by ripgrep search for common Uzbek words and JSX text patterns)
- Dev server compiles cleanly (no runtime errors in `dev.log`)

## Notes for downstream agents
- The `formatDuration` helper in `course-detail-view.tsx` now requires a `t` parameter — if you reuse it elsewhere, pass `t` from `useTranslation()`
- The `levelLabel(level, t)` helper in `course-detail-view.tsx` can be reused for any course-level display
- The `LOCALE_MAP` constant in both `dashboard-view.tsx` and `course-detail-view.tsx` maps `Language` → BCP-47 locale string for `toLocaleDateString` calls — feel free to extract to a shared lib if other views need it
