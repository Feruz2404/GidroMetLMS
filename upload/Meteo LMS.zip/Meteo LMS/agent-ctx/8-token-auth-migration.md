# Task 8 — Token Auth Migration (API routes)

## Goal
Update all API route files (except `auth/route.ts` and `auth/me/route.ts`, already done) to pass `req` parameter to `getCurrentUser()`, `requireAuth()`, and `requireRole(...)` calls. The auth helpers were migrated from cookie-based (read from `next/headers`) to token-based (read Bearer token from `req.headers.authorization`).

## What was changed
Updated **24 files** under `src/app/api/`:

| # | File | Handlers | Notes |
|---|------|----------|-------|
| 1 | `categories/route.ts` | GET | Had no `req` param → added `req: NextRequest` |
| 2 | `library/route.ts` | GET, POST | |
| 3 | `library/[id]/route.ts` | GET (uses `_req`), PATCH, DELETE | |
| 4 | `library/[id]/bookmark/route.ts` | GET, POST (both use `_req`) | |
| 5 | `library/[id]/download/route.ts` | POST | |
| 6 | `notifications/route.ts` | GET, POST | POST had no `req` param → added `req: NextRequest` |
| 7 | `notifications/[id]/route.ts` | PATCH (uses `_req`) | |
| 8 | `reports/route.ts` | GET | |
| 9 | `dashboard/route.ts` | GET | Had no `req` param → added `req: NextRequest` |
| 10 | `users/route.ts` | GET, POST (both use `requireRole`) | `requireRole('admin')` → `requireRole(req, 'admin')` |
| 11 | `users/[id]/route.ts` | GET (uses `_req`), PATCH, DELETE | All `requireRole('admin')` → `requireRole(req/_req, 'admin')` |
| 12 | `users/[id]/status/route.ts` | PATCH (uses `requireRole`) | |
| 13 | `courses/route.ts` | GET, POST | |
| 14 | `courses/[id]/route.ts` | GET, PATCH | |
| 15 | `courses/[id]/enroll/route.ts` | POST | |
| 16 | `courses/[id]/progress/route.ts` | POST | |
| 17 | `quizzes/route.ts` | GET, POST | |
| 18 | `quizzes/[id]/route.ts` | GET, PATCH | |
| 19 | `quizzes/[id]/attempt/route.ts` | POST | |
| 20 | `quizzes/attempts/[id]/route.ts` | GET, POST | |
| 21 | `certificates/route.ts` | GET | |
| 22 | `certificates/[id]/route.ts` | GET (uses `_req`), PATCH | |
| 23 | `certificates/generate/route.ts` | POST | |
| 24 | `certificates/auto/route.ts` | POST | |

## Strategy followed
- For handlers with a `req: NextRequest` first param → just pass `req`.
- For handlers with `_req: NextRequest` (underscore-prefixed, indicating previously unused) → pass `_req` as-is. No rename, since `getCurrentUser` accepts any object with a `.headers` property and the underscore-prefixed name is still a valid identifier. Renaming would have been a larger-than-necessary logic change.
- For handlers with NO `req` parameter at all (3 cases: `categories GET`, `notifications POST`, `dashboard GET`) → added `req: NextRequest` as the first parameter to the route handler function signature, then passed it. This is the only way to access the Authorization header.
- For `requireRole(...)`, the new signature is `requireRole(req, ...roles)` → `requireRole('admin')` became `requireRole(req, 'admin')`.

## Excluded (already done)
- `src/app/api/auth/route.ts`
- `src/app/api/auth/me/route.ts`
- `src/app/api/certificates/verify/[hash]/route.ts` — public endpoint, uses no auth helpers

## Verification
- `bun run lint` → passes with zero errors
- `rg "getCurrentUser\(\)|requireAuth\(\)" src/app/api` → **no matches** (every call now passes `req`)
- `rg "requireRole\(" src/app/api` → 6 matches, all using the new `requireRole(req, 'admin')` signature
- Dev server compiled and continues to serve requests; existing 401s for unauthenticated requests behave correctly (token not yet provided by client — that's a separate frontend concern, not part of this task)
