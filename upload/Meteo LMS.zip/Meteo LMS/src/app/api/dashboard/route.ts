import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser, ok, err } from '@/lib/auth'

// GET /api/dashboard — role-based stats
export async function GET(req: NextRequest) {
  try {
    const user = await getCurrentUser(req)
    if (!user) return err(401, 'Avtorizatsiya talab qilinadi')

    if (user.role === 'student') {
      const enrollments = await db.enrollment.findMany({
        where: { userId: user.id },
        include: {
          course: {
            select: {
              id: true,
              title: true,
              slug: true,
              thumbnailUrl: true,
              durationHours: true,
              level: true,
              tutor: { select: { firstName: true, lastName: true } },
              category: { select: { name: true, icon: true } },
              _count: { select: { lessons: true } },
            },
          },
        },
        orderBy: { startedAt: 'desc' },
      })

      const certificates = await db.certificate.findMany({
        where: { userId: user.id, status: 'active' },
        include: { course: { select: { id: true, title: true } } },
        orderBy: { issuedAt: 'desc' },
      })

      const attempts = await db.quizAttempt.findMany({
        where: { userId: user.id },
        include: { quiz: { select: { id: true, title: true, courseId: true } } },
        orderBy: { startedAt: 'desc' },
        take: 5,
      })

      const notifications = await db.notification.count({
        where: { userId: user.id, isRead: false },
      })

      const completed = enrollments.filter((e) => e.status === 'completed').length
      const inProgress = enrollments.filter((e) => e.status === 'active').length
      const avgProgress = enrollments.length
        ? Math.round(enrollments.reduce((s, e) => s + e.progress, 0) / enrollments.length)
        : 0

      // Weekly activity (last 7 days lesson completions)
      const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      const recentProgress = await db.lessonProgress.findMany({
        where: { userId: user.id, completedAt: { gte: weekAgo } },
        select: { completedAt: true },
      })
      const activityMap: Record<string, number> = {}
      for (let i = 6; i >= 0; i--) {
        const d = new Date(Date.now() - i * 24 * 60 * 60 * 1000)
        const key = d.toISOString().slice(0, 10)
        activityMap[key] = 0
      }
      recentProgress.forEach((p) => {
        if (p.completedAt) {
          const key = p.completedAt.toISOString().slice(0, 10)
          if (key in activityMap) activityMap[key]++
        }
      })

      return ok({
        role: 'student',
        stats: {
          enrolled: enrollments.length,
          completed,
          inProgress,
          certificates: certificates.length,
          avgProgress,
          unreadNotifications: notifications,
        },
        enrollments: enrollments.slice(0, 4),
        certificates: certificates.slice(0, 3),
        recentAttempts: attempts,
        weeklyActivity: Object.entries(activityMap).map(([date, count]) => ({ date, count })),
      })
    }

    if (user.role === 'tutor') {
      const courses = await db.course.findMany({
        where: { tutorId: user.id },
        include: {
          _count: { select: { enrollments: true, lessons: true } },
          category: { select: { name: true } },
        },
      })

      const courseIds = courses.map((c) => c.id)
      const enrollments = await db.enrollment.findMany({
        where: { courseId: { in: courseIds } },
        select: { id: true, progress: true, status: true, startedAt: true },
      })

      const attempts = await db.quizAttempt.findMany({
        where: { quiz: { courseId: { in: courseIds } } },
        select: { id: true, score: true, maxScore: true, passed: true, submittedAt: true },
      })

      const passed = attempts.filter((a) => a.passed).length
      const avgScore = attempts.length
        ? Math.round(attempts.reduce((s, a) => s + (a.maxScore ? (a.score / a.maxScore) * 100 : 0), 0) / attempts.length)
        : 0

      return ok({
        role: 'tutor',
        stats: {
          courses: courses.length,
          students: new Set(enrollments.map((e) => e.id)).size,
          totalEnrollments: enrollments.length,
          attempts: attempts.length,
          passed,
          avgScore,
        },
        courses: courses.slice(0, 5),
        recentAttempts: [],
      })
    }

    // Admin
    const totalStudents = await db.user.count({ where: { role: 'student' } })
    const totalTutors = await db.user.count({ where: { role: 'tutor' } })
    const totalCourses = await db.course.count({ where: { status: 'published' } })
    const totalCertificates = await db.certificate.count({ where: { status: 'active' } })
    const totalResources = await db.libraryResource.count({ where: { status: 'active' } })
    const totalEnrollments = await db.enrollment.count()

    const attempts = await db.quizAttempt.findMany({
      where: { status: 'graded' },
      select: { passed: true, percentage: true },
    })
    const passed = attempts.filter((a) => a.passed).length
    const avgScore = attempts.length
      ? Math.round(attempts.reduce((s, a) => s + a.percentage, 0) / attempts.length)
      : 0

    // 30-day active users
    const monthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
    const activeUsers = await db.activityLog.findMany({
      where: { createdAt: { gte: monthAgo }, action: 'login' },
      select: { userId: true, createdAt: true },
      distinct: ['userId'],
    })

    // Daily activity for last 14 days
    const dailyActive: Record<string, number> = {}
    for (let i = 13; i >= 0; i--) {
      const d = new Date(Date.now() - i * 24 * 60 * 60 * 1000)
      dailyActive[d.toISOString().slice(0, 10)] = 0
    }
    const logs = await db.activityLog.findMany({
      where: { createdAt: { gte: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000) }, action: 'login' },
      select: { createdAt: true, userId: true },
    })
    const seenPerDay: Record<string, Set<string>> = {}
    logs.forEach((l) => {
      const key = l.createdAt.toISOString().slice(0, 10)
      if (key in dailyActive) {
        if (!seenPerDay[key]) seenPerDay[key] = new Set()
        seenPerDay[key].add(l.userId)
      }
    })
    Object.entries(seenPerDay).forEach(([k, v]) => {
      dailyActive[k] = v.size
    })

    const topCourses = await db.course.findMany({
      take: 5,
      orderBy: { enrollments: { _count: 'desc' } },
      include: { _count: { select: { enrollments: true, lessons: true } } },
    })

    const recentCertificates = await db.certificate.findMany({
      take: 5,
      orderBy: { issuedAt: 'desc' },
      include: {
        user: { select: { firstName: true, lastName: true } },
        course: { select: { title: true } },
      },
    })

    return ok({
      role: 'admin',
      stats: {
        totalStudents,
        totalTutors,
        totalCourses,
        totalCertificates,
        totalResources,
        totalEnrollments,
        activeUsers: activeUsers.length,
        passRate: attempts.length ? Math.round((passed / attempts.length) * 100) : 0,
        avgScore,
      },
      dailyActive: Object.entries(dailyActive).map(([date, count]) => ({ date, count })),
      topCourses,
      recentCertificates,
    })
  } catch (e) {
    console.error('Dashboard error:', e)
    return err(500, 'Server xatosi')
  }
}

export const dynamic = 'force-dynamic'
