import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { ok, err } from '@/lib/auth'

// GET /api/certificates/verify/[hash] — PUBLIC verification endpoint (no auth required)
// Returns certificate by verifyHash if status="active" and (validUntil is null OR validUntil > now)
// Otherwise returns 404 with message
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ hash: string }> }
) {
  try {
    const { hash } = await params

    if (!hash || hash.length < 8) {
      return err(404, 'Sertifikat topilmadi')
    }

    const certificate = await db.certificate.findUnique({
      where: { verifyHash: hash },
      include: {
        user: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            middleName: true,
          },
        },
        course: { select: { id: true, title: true } },
        template: {
          select: {
            id: true,
            titleText: true,
            bodyText: true,
            primaryColor: true,
            accentColor: true,
            signerName: true,
            signerTitle: true,
          },
        },
      },
    })

    if (!certificate) {
      return err(404, 'Sertifikat topilmadi')
    }

    // Check status: only active certificates are publicly verifiable
    if (certificate.status === 'revoked') {
      return ok({
        found: true,
        status: 'revoked',
        certNumber: certificate.certNumber,
        message: 'Sertifikat bekor qilingan',
      })
    }

    // Check validity period
    const now = new Date()
    const isExpired =
      certificate.validUntil !== null && certificate.validUntil < now

    if (isExpired) {
      return ok({
        found: true,
        status: 'expired',
        certNumber: certificate.certNumber,
        validUntil: certificate.validUntil,
        message: 'Sertifikat amal qilish muddati tugagan',
      })
    }

    // Active and valid — return full public details
    return ok({
      found: true,
      status: 'active',
      id: certificate.id,
      certNumber: certificate.certNumber,
      score: certificate.score,
      maxScore: certificate.maxScore,
      percentage: certificate.percentage,
      issuedAt: certificate.issuedAt,
      validUntil: certificate.validUntil,
      verifyHash: certificate.verifyHash,
      user: certificate.user,
      course: certificate.course,
      template: certificate.template,
    })
  } catch (e) {
    console.error('GET /api/certificates/verify/[hash] error:', e)
    return err(500, 'Server xatosi')
  }
}

export const dynamic = 'force-dynamic'
