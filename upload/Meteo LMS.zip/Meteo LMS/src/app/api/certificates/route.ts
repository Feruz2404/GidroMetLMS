import { NextRequest } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser, ok, err } from '@/lib/auth'

// GET /api/certificates — paginated list (role-aware)
// Students: only their own active certificates (include course + template)
// Tutors/Admins: all certificates (include user + course + template), with filters:
//   search (user name OR cert number), courseId, status
// Query: page (1), limit (12)
export async function GET(req: NextRequest) {
  try {
    const user = await getCurrentUser(req)
    if (!user) return err(401, 'Avtorizatsiya talab qilinadi')

    const { searchParams } = new URL(req.url)
    const page = Math.max(1, parseInt(searchParams.get('page') ?? '1', 10))
    const limit = Math.min(60, Math.max(1, parseInt(searchParams.get('limit') ?? '12', 10)))
    const search = searchParams.get('search')?.trim() ?? ''
    const courseId = searchParams.get('courseId')?.trim() ?? ''
    const status = searchParams.get('status')?.trim() ?? ''

    const isStaff = user.role === 'tutor' || user.role === 'admin'

    // Base where clause — role-aware
    const where: Record<string, unknown> = {}
    if (!isStaff) {
      where.userId = user.id
      where.status = 'active'
    } else {
      if (status && ['active', 'revoked'].includes(status)) {
        where.status = status
      }
      if (courseId) where.courseId = courseId
      if (search) {
        where.OR = [
          { certNumber: { contains: search } },
          {
            user: {
              OR: [
                { firstName: { contains: search } },
                { lastName: { contains: search } },
                { middleName: { contains: search } },
              ],
            },
          },
        ]
      }
    }

    const include = {
      course: { select: { id: true, title: true } },
      template: {
        select: {
          id: true,
          titleText: true,
          primaryColor: true,
          accentColor: true,
          signerName: true,
          signerTitle: true,
        },
      },
      ...(isStaff
        ? {
            user: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                middleName: true,
              },
            },
          }
        : {}),
    }

    const [total, certificates] = await Promise.all([
      db.certificate.count({ where: where as never }),
      db.certificate.findMany({
        where: where as never,
        orderBy: { issuedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        include,
      }),
    ])

    return ok(certificates, {
      total,
      page,
      pages: Math.max(1, Math.ceil(total / limit)),
      limit,
    })
  } catch (e) {
    console.error('GET /api/certificates error:', e)
    return err(500, 'Server xatosi')
  }
}

export const dynamic = 'force-dynamic'
