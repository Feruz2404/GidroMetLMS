// GidroEdu LMS - Seed script
// Populates the database with demo data for all 6 modules

import { PrismaClient } from '@prisma/client'
import { hashPassword } from '../src/lib/auth'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding GidroEdu LMS database...')

  // Clean existing data
  await prisma.notification.deleteMany()
  await prisma.certificate.deleteMany()
  await prisma.certificateTemplate.deleteMany()
  await prisma.resourceBookmark.deleteMany()
  await prisma.resourceDownload.deleteMany()
  await prisma.libraryResource.deleteMany()
  await prisma.quizAnswer.deleteMany()
  await prisma.quizAttempt.deleteMany()
  await prisma.answerOption.deleteMany()
  await prisma.question.deleteMany()
  await prisma.quiz.deleteMany()
  await prisma.lessonProgress.deleteMany()
  await prisma.enrollment.deleteMany()
  await prisma.lesson.deleteMany()
  await prisma.section.deleteMany()
  await prisma.course.deleteMany()
  await prisma.category.deleteMany()
  await prisma.activityLog.deleteMany()
  await prisma.userSession.deleteMany()
  await prisma.user.deleteMany()
  await prisma.setting.deleteMany()

  // ============ USERS ============
  const admin = await prisma.user.create({
    data: {
      email: 'admin@gidroedu.uz',
      username: 'admin',
      passwordHash: hashPassword('admin123'),
      role: 'admin',
      firstName: 'Akmal',
      lastName: 'Rahimov',
      middleName: 'Karimovich',
      phone: '+998901234567',
      department: 'Markaziy apparat',
      position: 'Bosh administrator',
      emailVerifiedAt: new Date(),
      lastLoginAt: new Date(),
    },
  })

  const tutor1 = await prisma.user.create({
    data: {
      email: 'tutor@gidroedu.uz',
      username: 'tutor',
      passwordHash: hashPassword('tutor123'),
      role: 'tutor',
      firstName: 'Dilshod',
      lastName: 'Yusupov',
      middleName: 'Toshmatovich',
      phone: '+998902345678',
      department: 'Gidrologiya kafedrasi',
      position: 'Katta o\'qituvchi',
      emailVerifiedAt: new Date(),
      lastLoginAt: new Date(),
    },
  })

  const tutor2 = await prisma.user.create({
    data: {
      email: 'karimov@gidroedu.uz',
      username: 'karimov',
      passwordHash: hashPassword('tutor123'),
      role: 'tutor',
      firstName: 'Bekzod',
      lastName: 'Karimov',
      middleName: 'Ergashevich',
      phone: '+998903456789',
      department: 'Meteorologiya kafedrasi',
      position: 'Dosent',
      emailVerifiedAt: new Date(),
    },
  })

  const student = await prisma.user.create({
    data: {
      email: 'student@gidroedu.uz',
      username: 'student',
      passwordHash: hashPassword('student123'),
      role: 'student',
      firstName: 'Nodira',
      lastName: 'Abdullayeva',
      middleName: 'Saidovna',
      phone: '+998912345678',
      department: 'Gidrologiya',
      position: 'Talaba, 3-kurs',
      emailVerifiedAt: new Date(),
      lastLoginAt: new Date(),
    },
  })

  // More students
  const students = [student]
  const studentNames = [
    ['Jasur', 'To\'xtayev', 'Rustamovich'],
    ['Malika', 'Saidova', 'Anvarovna'],
    ['Sardor', 'Ergashev', 'Bahodir o\'g\'li'],
    ['Kamola', 'Nazarova', 'Sherzodovna'],
    ['Aziz', 'Xolmatov', 'Po\'latovich'],
    ['Gulnora', 'Yo\'ldosheva', 'Mirzayevna'],
    ['Sherzod', 'Aliyev', 'Quvondiqovich'],
    ['Zarina', 'Hasanova', 'Tolibovna'],
  ]
  for (const [fn, ln, mn] of studentNames) {
    const s = await prisma.user.create({
      data: {
        email: `${fn.toLowerCase().replace(/'/g, '')}.${ln.toLowerCase().replace(/'/g, '')}@student.uz`,
        username: `${fn.toLowerCase().replace(/'/g, '')}.${ln.toLowerCase().replace(/'/g, '')}`,
        passwordHash: hashPassword('student123'),
        role: 'student',
        firstName: fn,
        lastName: ln,
        middleName: mn,
        department: 'Gidrologiya',
        position: 'Talaba',
      },
    })
    students.push(s)
  }

  console.log(`  ✓ Created ${3 + students.length} users`)

  // ============ CATEGORIES ============
  const cats = await Promise.all(
    [
      ['Gidrologiya', 'gidrologiya', 'Suv resurslari va gidrologik jarayonlar', '💧', 1],
      ['Meteorologiya', 'meteorologiya', 'Atmosfera va ob-havo sharoitlari', '☁️', 2],
      ['Klimatologiya', 'klimatologiya', 'Iqlim va iqlim o\'zgarishlari', '🌍', 3],
      ['Gidrometriya', 'gidrometriya', 'O\'lchov usullari va asboblari', '📊', 4],
      ['Ekologiya', 'ekologiya', 'Atrof-muhit muhofazasi', '🌱', 5],
      ['Agrometeorologiya', 'agrometeorologiya', 'Qishloq xo\'jaligi meteorologiyasi', '🌾', 6],
    ].map(([name, slug, desc, icon, order]) =>
      prisma.category.create({
        data: { name: name as string, slug: slug as string, description: desc as string, icon: icon as string, order: order as number },
      })
    )
  )

  // ============ COURSES ============
  const coursesData = [
    {
      title: 'Gidrologiya asoslari',
      slug: 'gidrologiya-asoslari',
      description: 'Suv aylanishi, daryo oqimlari va gidrologik hisob-kitoblar bo\'yicha asosiy kurs. Talabalar yer yuzasidagi suv resurslarini o\'rganadi.',
      categoryId: cats[0].id,
      tutorId: tutor1.id,
      durationHours: 40,
      level: 'beginner',
      isMandatory: true,
      thumbnail: 'https://images.unsplash.com/photo-1582972236019-ea4af5ffe587?w=800',
    },
    {
      title: 'Sinoptik meteorologiya',
      slug: 'sinoptik-meteorologiya',
      description: 'Sinoptik xaritalar, atmosfera jarayonlari tahlili va ob-havo prognozi usullari.',
      categoryId: cats[1].id,
      tutorId: tutor2.id,
      durationHours: 60,
      level: 'intermediate',
      isMandatory: true,
      thumbnail: 'https://images.unsplash.com/photo-1561553543-e4c7b608b98d?w=800',
    },
    {
      title: 'Iqlim o\'zgarishi va uning oqibatlari',
      slug: 'iqlim-ozgarishi',
      description: 'Global isish, issiqxona gazlari va iqlim modelini o\'rganish bo\'yicha zamonaviy kurs.',
      categoryId: cats[2].id,
      tutorId: tutor2.id,
      durationHours: 32,
      level: 'advanced',
      thumbnail: 'https://images.unsplash.com/photo-1569163139599-0f4515e4f7b6?w=800',
    },
    {
      title: 'Gidrometrik o\'lchov asboblari',
      slug: 'gidrometrik-asboblar',
      description: 'Suv sarfi, sathini va yog\'in miqdorini o\'lchaydigan asboblarning qurilishi va ishlash printsipi.',
      categoryId: cats[3].id,
      tutorId: tutor1.id,
      durationHours: 24,
      level: 'beginner',
      thumbnail: 'https://images.unsplash.com/photo-1581092160562-40aa08e78837?w=800',
    },
    {
      title: 'Atrof-muhit monitoringi',
      slug: 'atrof-muhit-monitoringi',
      description: 'Ekologik holatni baholash, ifloslanish manbalari va monitoring tizimlari.',
      categoryId: cats[4].id,
      tutorId: tutor2.id,
      durationHours: 28,
      level: 'intermediate',
      thumbnail: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=800',
    },
    {
      title: 'Agrometeorologik prognozlar',
      slug: 'agrometeorologiya-prognozlar',
      description: 'Qishloq xo\'jaligi ekinlari uchun ob-havo prognozlari va agroiqlim tahlili.',
      categoryId: cats[5].id,
      tutorId: tutor1.id,
      durationHours: 36,
      level: 'intermediate',
      thumbnail: 'https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800',
    },
  ]

  const courses = []
  for (const c of coursesData) {
    const course = await prisma.course.create({
      data: {
        title: c.title,
        description: c.description,
        slug: c.slug,
        categoryId: c.categoryId,
        tutorId: c.tutorId,
        thumbnailUrl: c.thumbnail,
        durationHours: c.durationHours,
        level: c.level,
        status: 'published',
        isMandatory: c.isMandatory ?? false,
        passPercentage: 70,
        maxAttempts: 3,
        validDays: 730,
        createdBy: admin.id,
        publishedAt: new Date(),
      },
    })
    courses.push(course)
  }
  console.log(`  ✓ Created ${courses.length} courses`)

  // ============ SECTIONS & LESSONS ============
  const sectionTitles = [
    ['Modul 1: Kirish', 'Asosiy tushunchalar va terminologiya'],
    ['Modul 2: Nazariy asoslar', 'Ilmiy fundament va qonuniyatlar'],
    ['Modul 3: Amaliy qo\'llanma', 'Real vaziyatlarda qo\'llash'],
  ]

  for (const course of courses) {
    for (let i = 0; i < sectionTitles.length; i++) {
      const section = await prisma.section.create({
        data: {
          courseId: course.id,
          title: sectionTitles[i][0],
          description: sectionTitles[i][1],
          order: i + 1,
        },
      })

      // 2 lessons per section
      const lessonTypes = ['video', 'text', 'pdf']
      for (let j = 0; j < 3; j++) {
        const type = lessonTypes[j]
        await prisma.lesson.create({
          data: {
            courseId: course.id,
            sectionId: section.id,
            title: `${j + 1}.${i + 1}-dars: ${type === 'video' ? 'Video ma\'ruza' : type === 'text' ? 'Nazariy material' : 'Amaliy qo\'llanma'}`,
            description: `${sectionTitles[i][0]} bo\'yicha ${type} formatidagi dars.`,
            content: type === 'text' ? `# ${course.title}\n\nBu darsda biz **${sectionTitles[i][0]}** mavzusini o\'rganamiz.\n\n## Asosiy tushunchalar\n\n1. Birinchi tushuncha\n2. Ikkinchi tushuncha\n3. Uchinchi tushuncha\n\n## Xulosa\n\nDars yakunida talaba asosiy tushunchalarni o\'zlashtirgan bo\'lishi kerak.\n\n---\n*Gidrometeorologiya Texnikumi*` : null,
            type,
            videoUrl: type === 'video' ? 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' : null,
            fileUrl: type === 'pdf' ? '/sample.pdf' : null,
            durationMin: type === 'video' ? 25 : type === 'text' ? 15 : 20,
            order: j + 1,
            isFree: i === 0 && j === 0,
          },
        })
      }
    }
  }
  console.log(`  ✓ Created sections and lessons`)

  // ============ ENROLLMENTS ============
  for (const s of students) {
    for (let i = 0; i < Math.min(4, courses.length); i++) {
      const c = courses[i]
      await prisma.enrollment.create({
        data: {
          courseId: c.id,
          userId: s.id,
          status: 'active',
          progress: Math.floor(Math.random() * 80) + 10,
          startedAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000),
        },
      })
    }
  }
  console.log(`  ✓ Created enrollments`)

  // ============ LESSON PROGRESS ============
  const allLessons = await prisma.lesson.findMany()
  const enrollments = await prisma.enrollment.findMany()
  for (const e of enrollments) {
    const courseLessons = allLessons.filter(l => l.courseId === e.courseId)
    for (const lesson of courseLessons.slice(0, Math.floor(courseLessons.length * (e.progress / 100)))) {
      await prisma.lessonProgress.create({
        data: {
          lessonId: lesson.id,
          userId: e.userId,
          isCompleted: true,
          watchTimeSec: lesson.durationMin * 60,
          completedAt: new Date(),
        },
      })
    }
  }
  console.log(`  ✓ Created lesson progress`)

  // ============ QUIZZES ============
  const quiz1 = await prisma.quiz.create({
    data: {
      title: 'Gidrologiya asoslari - yakuniy test',
      description: 'Kurs bo\'yicha bilimlarni tekshirish uchun yakuniy test.',
      courseId: courses[0].id,
      timeLimitMin: 30,
      passingScore: 70,
      maxAttempts: 3,
      shuffleQuestions: true,
      showAnswers: true,
      status: 'published',
      createdBy: tutor1.id,
    },
  })

  const quiz2 = await prisma.quiz.create({
    data: {
      title: 'Meteorologiya - oraliq nazorat',
      description: 'Sinoptik meteorologiya bo\'yicha oraliq nazorat testi.',
      courseId: courses[1].id,
      timeLimitMin: 20,
      passingScore: 60,
      maxAttempts: 2,
      status: 'published',
      createdBy: tutor2.id,
    },
  })

  // Questions for quiz 1
  const q1 = await prisma.question.create({
    data: {
      quizId: quiz1.id,
      type: 'single_choice',
      text: 'Gidrologiya qanday fan?',
      points: 2,
      explanation: 'Gidrologiya Yer hududidagi suv va uning aylanishini o\'rganadi.',
      order: 1,
    },
  })
  await prisma.answerOption.createMany({
    data: [
      { questionId: q1.id, text: 'Suv va uning aylanishini o\'rganadigan fan', isCorrect: true, order: 1 },
      { questionId: q1.id, text: 'Faqat ob-havoni o\'rganadigan fan', isCorrect: false, order: 2 },
      { questionId: q1.id, text: 'Tuproqni o\'rganadigan fan', isCorrect: false, order: 3 },
      { questionId: q1.id, text: 'Atmosferani o\'rganadigan fan', isCorrect: false, order: 4 },
    ],
  })

  const q2 = await prisma.question.create({
    data: {
      quizId: quiz1.id,
      type: 'multiple_choice',
      text: 'Quyidagilardan qaysilari suv aylanishi bosqichlaridan hisoblanadi?',
      points: 3,
      order: 2,
    },
  })
  await prisma.answerOption.createMany({
    data: [
      { questionId: q2.id, text: 'Bug\'lanish', isCorrect: true, order: 1 },
      { questionId: q2.id, text: 'Kondensatsiya', isCorrect: true, order: 2 },
      { questionId: q2.id, text: 'Yog\'in', isCorrect: true, order: 3 },
      { questionId: q2.id, text: 'Eroziya', isCorrect: false, order: 4 },
      { questionId: q2.id, text: 'Sublimatsiya', isCorrect: false, order: 5 },
    ],
  })

  const q3 = await prisma.question.create({
    data: {
      quizId: quiz1.id,
      type: 'true_false',
      text: 'Daryo oqimi m^3/s bilan o\'lchanadi.',
      points: 1,
      order: 3,
    },
  })
  await prisma.answerOption.createMany({
    data: [
      { questionId: q3.id, text: 'Ha, to\'g\'ri', isCorrect: true, order: 1 },
      { questionId: q3.id, text: 'Yo\'q, noto\'g\'ri', isCorrect: false, order: 2 },
    ],
  })

  const q4 = await prisma.question.create({
    data: {
      quizId: quiz1.id,
      type: 'fill_blank',
      text: 'Suvning yer yuzasida bug\'lanishi va atmosferaga ko\'tarilishi jarayoni ____ deyiladi.',
      points: 2,
      order: 4,
    },
  })
  await prisma.answerOption.createMany({
    data: [
      { questionId: q4.id, text: 'evaporatsiya', isCorrect: true, order: 1 },
    ],
  })

  const q5 = await prisma.question.create({
    data: {
      quizId: quiz1.id,
      type: 'single_choice',
      text: 'O\'zbekistondagi eng yirik daryo qaysi?',
      points: 2,
      order: 5,
    },
  })
  await prisma.answerOption.createMany({
    data: [
      { questionId: q5.id, text: 'Amudaryo', isCorrect: true, order: 1 },
      { questionId: q5.id, text: 'Sirdaryo', isCorrect: false, order: 2 },
      { questionId: q5.id, text: 'Zarafshon', isCorrect: false, order: 3 },
      { questionId: q5.id, text: 'Chirchiq', isCorrect: false, order: 4 },
    ],
  })

  // Questions for quiz 2
  const q6 = await prisma.question.create({
    data: {
      quizId: quiz2.id,
      type: 'single_choice',
      text: 'Sinoptik xaritada front qanday tasvirlanadi?',
      points: 2,
      order: 1,
    },
  })
  await prisma.answerOption.createMany({
    data: [
      { questionId: q6.id, text: 'Chiziq va triangulyatsiya belgilari bilan', isCorrect: true, order: 1 },
      { questionId: q6.id, text: 'Faqat nuqtalar bilan', isCorrect: false, order: 2 },
      { questionId: q6.id, text: 'Rangli dog\'lar bilan', isCorrect: false, order: 3 },
    ],
  })

  const q7 = await prisma.question.create({
    data: {
      quizId: quiz2.id,
      type: 'true_false',
      text: 'Siklon past bosimli sohadir.',
      points: 1,
      order: 2,
    },
  })
  await prisma.answerOption.createMany({
    data: [
      { questionId: q7.id, text: 'Ha, to\'g\'ri', isCorrect: true, order: 1 },
      { questionId: q7.id, text: 'Yo\'q, noto\'g\'ri', isCorrect: false, order: 2 },
    ],
  })

  const q8 = await prisma.question.create({
    data: {
      quizId: quiz2.id,
      type: 'multiple_choice',
      text: 'Quyidagi bulut turlaridan qaysilari past bo\'yli bulutlardir?',
      points: 3,
      order: 3,
    },
  })
  await prisma.answerOption.createMany({
    data: [
      { questionId: q8.id, text: 'Stratus', isCorrect: true, order: 1 },
      { questionId: q8.id, text: 'Nimbostratus', isCorrect: true, order: 2 },
      { questionId: q8.id, text: 'Cirrus', isCorrect: false, order: 3 },
      { questionId: q8.id, text: 'Cumulus', isCorrect: false, order: 4 },
    ],
  })
  console.log(`  ✓ Created quizzes with questions`)

  // Quiz attempts (some completed)
  for (const s of [students[0], students[1], students[3]]) {
    const attempt = await prisma.quizAttempt.create({
      data: {
        quizId: quiz1.id,
        userId: s.id,
        status: 'graded',
        score: 7,
        maxScore: 10,
        percentage: 70,
        passed: true,
        startedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        submittedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000 + 25 * 60 * 1000),
        timeSpentSec: 1500,
      },
    })
    // Create answers
    const qs = await prisma.question.findMany({ where: { quizId: quiz1.id }, include: { options: true } })
    for (const question of qs) {
      const correct = question.options.find(o => o.isCorrect)
      if (correct) {
        await prisma.quizAnswer.create({
          data: {
            attemptId: attempt.id,
            questionId: question.id,
            userId: s.id,
            selectedOptions: JSON.stringify([correct.id]),
            isCorrect: true,
            pointsAwarded: question.points,
          },
        })
      }
    }
  }
  console.log(`  ✓ Created quiz attempts`)

  // ============ LIBRARY RESOURCES ============
  const resources = [
    { title: 'Gidrologiya darsligi', type: 'book', category: 'Gidrologiya', author: 'Prof. A.Tursunov', year: 2022, pages: 412, fileType: 'pdf', fileSize: 12400000 },
    { title: 'Meteorologiya asoslari', type: 'book', category: 'Meteorologiya', author: 'Prof. B.Saidov', year: 2021, pages: 356, fileType: 'pdf', fileSize: 9800000 },
    { title: 'Suv resurslarini boshqarish', type: 'book', category: 'Gidrologiya', author: 'Dr. M.Karimov', year: 2023, pages: 288, fileType: 'pdf', fileSize: 8500000 },
    { title: 'Iqlim o\'zgarishi: global muammo', type: 'article', category: 'Klimatologiya', author: 'UN IPCC', year: 2023, fileType: 'pdf', fileSize: 3200000 },
    { title: 'Gidrometrik o\'lchovlar qo\'llanmasi', type: 'document', category: 'Gidrometriya', author: 'Uzgidromet', year: 2022, fileType: 'docx', fileSize: 5600000 },
    { title: 'Atmosfera jarayonlari video ma\'ruza', type: 'video', category: 'Meteorologiya', author: 'D.Yusupov', year: 2024, fileType: 'mp4', fileSize: 245000000 },
    { title: 'O\'zbekiston Respublikasining Suv kodeksi', type: 'normative', category: 'Normativ', author: 'O\'zR Oliy Majlisi', year: 2022, fileType: 'pdf', fileSize: 2100000 },
    { title: 'Agrometeorologik kuzatishlar bo\'yicha yo\'riqnoma', type: 'normative', category: 'Agrometeorologiya', author: 'Uzgidromet', year: 2021, fileType: 'pdf', fileSize: 4100000 },
    { title: 'Ekologik monitoring usullari', type: 'article', category: 'Ekologiya', author: 'Dr. N.Hasanova', year: 2023, fileType: 'pdf', fileSize: 3800000 },
    { title: 'Tabiatni muhofaza qilish huquqiy asoslari', type: 'book', category: 'Ekologiya', author: 'Prof. R.Alimov', year: 2020, pages: 224, fileType: 'pdf', fileSize: 6700000 },
    { title: 'Qor va muzliklar gidrologiyasi', type: 'article', category: 'Gidrologiya', author: 'Dr. S.Ergashev', year: 2023, fileType: 'pdf', fileSize: 2900000 },
    { title: 'Radiosonda ma\'lumotlari tahlili', type: 'document', category: 'Meteorologiya', author: 'Uzgidromet', year: 2024, fileType: 'pdf', fileSize: 4900000 },
  ]

  for (const r of resources) {
    await prisma.libraryResource.create({
      data: {
        title: r.title,
        description: `${r.title} - batafsil tavsif. Mazkur resurs ${r.category} bo\'limida ${r.author} tomonidan tayyorlangan.`,
        type: r.type,
        category: r.category,
        author: r.author,
        year: r.year,
        pages: r.pages || null,
        language: 'uz',
        fileUrl: '#',
        fileSize: r.fileSize,
        fileType: r.fileType,
        coverUrl: r.type === 'video' ? 'https://images.unsplash.com/photo-1561553543-e4c7b608b98d?w=400' : null,
        tags: r.category.toLowerCase(),
        downloadCount: Math.floor(Math.random() * 200),
        viewCount: Math.floor(Math.random() * 500),
        uploadedBy: admin.id,
        status: 'active',
      },
    })
  }
  console.log(`  ✓ Created ${resources.length} library resources`)

  // Bookmarks for first student
  const allResources = await prisma.libraryResource.findMany()
  for (const r of allResources.slice(0, 3)) {
    await prisma.resourceBookmark.create({
      data: { resourceId: r.id, userId: student.id },
    })
  }

  // ============ CERTIFICATE TEMPLATE ============
  const template = await prisma.certificateTemplate.create({
    data: {
      name: 'Standart sertifikat',
      titleText: 'SERTIFIKAT',
      bodyText: 'Ushbu sertifikat quyidagi talabaga {courseName} kursini muvaffaqiyatli yakunlagani uchun berildi.',
      signerName: 'D.Yusupov',
      signerTitle: 'Direktor',
      primaryColor: '#0f766e',
      accentColor: '#ca8a04',
      isActive: true,
    },
  })

  // ============ CERTIFICATES ============
  for (const s of [students[0], students[1], students[3]]) {
    await prisma.certificate.create({
      data: {
        certNumber: `SRT-20250${Math.floor(Math.random() * 9000 + 1000)}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
        userId: s.id,
        courseId: courses[0].id,
        templateId: template.id,
        score: 7,
        maxScore: 10,
        percentage: 70,
        issuedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        validUntil: new Date(Date.now() + 730 * 24 * 60 * 60 * 1000),
        status: 'active',
        verifyHash: Math.random().toString(36).substring(2, 22) + Math.random().toString(36).substring(2, 22),
      },
    })
  }
  console.log(`  ✓ Created certificates`)

  // ============ NOTIFICATIONS ============
  for (const s of students) {
    await prisma.notification.create({
      data: {
        userId: s.id,
        type: 'info',
        title: 'Yangi kurs qo\'shildi',
        message: 'Gidrologiya asoslari kursiga ro\'yxatdan o\'tdingiz.',
        link: 'courses',
      },
    })
    await prisma.notification.create({
      data: {
        userId: s.id,
        type: 'success',
        title: 'Dars yakunlandi',
        message: 'Siz 1.1-darsni muvaffaqiyatli yakunladingiz.',
      },
    })
  }
  console.log(`  ✓ Created notifications`)

  // ============ SETTINGS ============
  await prisma.setting.createMany({
    data: [
      { key: 'site_name', value: 'GidroEdu LMS' },
      { key: 'institution', value: 'Gidrometeorologiya Texnikumi' },
      { key: 'primary_language', value: 'uz' },
      { key: 'max_upload_size_mb', value: '500' },
      { key: 'session_timeout_min', value: '15' },
      { key: 'pass_percentage_default', value: '70' },
    ],
  })

  // ============ ACTIVITY LOGS ============
  for (const u of [admin, tutor1, student]) {
    for (let i = 0; i < 5; i++) {
      await prisma.activityLog.create({
        data: {
          userId: u.id,
          action: i === 0 ? 'login' : i === 1 ? 'view_course' : i === 2 ? 'take_quiz' : i === 3 ? 'download_resource' : 'view_certificate',
          ipAddress: '192.168.1.' + Math.floor(Math.random() * 254 + 1),
          createdAt: new Date(Date.now() - i * 24 * 60 * 60 * 1000),
        },
      })
    }
  }
  console.log(`  ✓ Created activity logs`)

  console.log('\n✅ Seed complete!')
  console.log('\n📋 Demo accounts:')
  console.log('   Admin:    admin@gidroedu.uz / admin123')
  console.log('   Tutor:    tutor@gidroedu.uz / tutor123')
  console.log('   Student:  student@gidroedu.uz / student123')
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
